import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:math' show Random;
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'chat_room_page.dart';
import 'notification_page.dart';
import 'bug_group_page.dart';
import 'custom_payload.dart';
import 'ular.dart';

// ─── COLORS ────────────────────────────────────────────────────────────────────
const Color kBg      = Color(0xFF09090B);
const Color kCard    = Color(0xFF18181B);
const Color kCardAlt = Color(0xFF1C1C1F);
const Color kBorder  = Color(0xFF27272A);
const Color kBlue    = Color(0xFF1565C0);
const Color kBlueMid = Color(0xFF1976D2);
const Color kBlueLight = Color(0xFF42A5F5);
const Color kPink    = Color(0xFFE91E8C);
const Color kPurple  = Color(0xFF7C4DFF);
const Color kYellow  = Color(0xFFFFD600);
const Color kWhite   = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

// ─── Prayer Time Service ───────────────────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return const Color(0xFFF59E0B);
    case 'admin':    return const Color(0xFFEF4444);
    case 'reseller': return kBlue;
    case 'vip':      return kPurple;
    default:         return kBlue;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return Icons.workspace_premium_rounded;
    case 'admin':    return Icons.admin_panel_settings_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'vip':      return Icons.star_rounded;
    default:         return Icons.person_rounded;
  }
}

// ─── ANIMATED DOT ──────────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

// ─── HEXAGON PATTERN PAINTER ──────────────────────────────────────────────────
class _HexagonPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = kBlue.withOpacity(0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const double w = 72.0;
    const double h = 52.0;

    for (double row = -1; row * h < size.height + h * 2; row++) {
      for (double col = -1; col * w < size.width + w * 2; col++) {
        final double offsetX = (row.toInt() % 2 == 0) ? 0 : w * 0.5;
        final cx = col * w + offsetX;
        final cy = row * h;
        _drawDiamond(canvas, paint, Offset(cx, cy), w * 0.5, h * 0.5);
      }
    }
  }

  void _drawDiamond(Canvas canvas, Paint paint, Offset center, double hw, double hh) {
    final path = Path()
      ..moveTo(center.dx, center.dy - hh)
      ..lineTo(center.dx + hw, center.dy)
      ..lineTo(center.dx, center.dy + hh)
      ..lineTo(center.dx - hw, center.dy)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── GRID PATTERN PAINTER ─────────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;
  const _GridPatternPainter({required this.gridColor, required this.lineColor, required this.spacing});
  @override
  void paint(Canvas canvas, Size size) {
    final paintGrid = Paint()..color = gridColor..strokeWidth = 0.8..style = PaintingStyle.stroke;
    final paintLines = Paint()..color = lineColor..strokeWidth = 0.4..style = PaintingStyle.stroke;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintGrid);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintGrid);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), paintLines);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), paintLines);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── NOTCH CLIPPER ────────────────────────────────────────────────────────────
class NotchClipper extends CustomClipper<Path> {
  final double notchOffset;
  final double notchRadius;
  final double barHeight;
  final double totalWidth;

  NotchClipper({
    required this.notchOffset,
    required this.notchRadius,
    required this.barHeight,
    required this.totalWidth,
  });

  @override
  Path getClip(Size size) {
    final path = Path();
    final double radius = 30; // corner radius of bar
    final double w = size.width;
    final double h = size.height;

    // Start from top-left corner
    path.moveTo(radius, 0);

    // Left top corner arc
    path.arcTo(
      Rect.fromLTWH(0, 0, radius * 2, radius * 2),
      math.pi,
      math.pi / 2,
      false,
    );

    // Draw top edge until notch start
    final double notchStart = (notchOffset - notchRadius).clamp(radius, w - radius);
    final double notchEnd = (notchOffset + notchRadius).clamp(radius, w - radius);

    path.lineTo(notchStart, 0);

    // Draw notch as a smooth concave curve (quadratic bezier)
    final double controlY = notchRadius * 1.2;
    path.quadraticBezierTo(notchOffset - notchRadius * 0.3, controlY, notchOffset, notchRadius * 1.0);
    path.quadraticBezierTo(notchOffset + notchRadius * 0.3, controlY, notchEnd, 0);

    // Continue to right
    path.lineTo(w - radius, 0);

    // Right top corner arc
    path.arcTo(
      Rect.fromLTWH(w - radius * 2, 0, radius * 2, radius * 2),
      math.pi * 1.5,
      math.pi / 2,
      false,
    );

    // Right edge
    path.lineTo(w, h - radius);

    // Bottom right corner
    path.arcTo(
      Rect.fromLTWH(w - radius * 2, h - radius * 2, radius * 2, radius * 2),
      0,
      math.pi / 2,
      false,
    );

    // Bottom edge
    path.lineTo(radius, h);

    // Bottom left corner
    path.arcTo(
      Rect.fromLTWH(0, h - radius * 2, radius * 2, radius * 2),
      math.pi / 2,
      math.pi / 2,
      false,
    );

    // Left edge
    path.close();

    return path;
  }

  @override
  bool shouldReclip(covariant NotchClipper oldClipper) {
    return oldClipper.notchOffset != notchOffset ||
        oldClipper.notchRadius != notchRadius ||
        oldClipper.barHeight != barHeight ||
        oldClipper.totalWidth != totalWidth;
  }
}

// ─── ANIMATED NOTCH BOTTOM NAV ──────────────────────────────────────────────
class _AnimatedNotchBottomNav extends StatefulWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const _AnimatedNotchBottomNav({
    required this.currentIndex,
    required this.onTap,
  });

  @override
  _AnimatedNotchBottomNavState createState() => _AnimatedNotchBottomNavState();
}

class _AnimatedNotchBottomNavState extends State<_AnimatedNotchBottomNav>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _notchAnimation;
  double _notchOffset = 0.0;
  double _targetOffset = 0.0;
  bool _isInitialized = false;

  // 4 items: Home, Bug, Tools, Profile
  final List<IconData> _icons = const [
    Icons.home_rounded,
    FontAwesomeIcons.whatsapp,
    Icons.build_rounded,
    Icons.person_rounded,
  ];

  final List<String> _labels = const [
    'Home',
    'Bug',
    'Tools',
    'Profile',
  ];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _notchAnimation = Tween<double>(begin: 0, end: 0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
    _notchAnimation.addListener(() {
      if (mounted) {
        setState(() {
          _notchOffset = _notchAnimation.value;
        });
      }
    });
  }

  @override
  void didUpdateWidget(_AnimatedNotchBottomNav oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.currentIndex != oldWidget.currentIndex) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _animateToIndex(widget.currentIndex);
        }
      });
    }
  }

  void _animateToIndex(int index) {
    final RenderBox? renderBox = context.findRenderObject() as RenderBox?;
    if (renderBox == null) return;
    final width = renderBox.size.width;
    final tabWidth = width / 4; // changed from 5 to 4
    final newOffset = tabWidth * (index + 0.5);
    _targetOffset = newOffset;

    if (!_isInitialized) {
      setState(() {
        _notchOffset = newOffset;
        _isInitialized = true;
      });
      return;
    }

    _notchAnimation = Tween<double>(begin: _notchOffset, end: newOffset).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
    _controller.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final tabWidth = width / 4; // changed from 5 to 4

        if (!_isInitialized) {
          _notchOffset = tabWidth * (widget.currentIndex + 0.5);
          _targetOffset = _notchOffset;
          _isInitialized = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) setState(() {});
          });
        }

        return SizedBox(
          height: 66 + 16,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              // Dark bar with notch
              ClipPath(
                clipper: NotchClipper(
                  notchOffset: _notchOffset,
                  notchRadius: 22,
                  barHeight: 66,
                  totalWidth: width,
                ),
                child: Container(
                  height: 66,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0D0D12),
                    borderRadius: BorderRadius.circular(30),
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFF0D0D0F), Color(0xFF090909)],
                    ),
                    border: Border.all(
                      color: const Color(0xFF2A2A2A).withOpacity(0.5),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF000000).withOpacity(0.6),
                        blurRadius: 24,
                        offset: const Offset(0, 8),
                      ),
                      BoxShadow(
                        color: const Color(0xFF1565C0).withOpacity(0.08),
                        blurRadius: 30,
                        spreadRadius: -5,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                ),
              ),

              // Active floating white circle (with glow)
              Positioned(
                left: _notchOffset - 28,
                top: -12,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF1565C0).withOpacity(0.5),
                        blurRadius: 24,
                        spreadRadius: 6,
                      ),
                      BoxShadow(
                        color: const Color(0xFF1565C0).withOpacity(0.3),
                        blurRadius: 40,
                        spreadRadius: 10,
                      ),
                    ],
                  ),
                  child: Icon(
                    _icons[widget.currentIndex],
                    color: const Color(0xFF0D0D12),
                    size: 28,
                  ),
                ),
              ),

              // Inactive items (icons and labels) – 4 items
              ...List.generate(4, (index) {
                final isActive = index == widget.currentIndex;
                final xPos = tabWidth * (index + 0.5);

                return Positioned(
                  left: xPos - 20,
                  bottom: 8,
                  child: GestureDetector(
                    onTap: () => widget.onTap(index),
                    behavior: HitTestBehavior.opaque,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (!isActive)
                          Icon(
                            _icons[index],
                            color: const Color(0xFF6C6C6C),
                            size: 22,
                          ),
                        const SizedBox(height: 2),
                        Text(
                          _labels[index],
                          style: TextStyle(
                            color: isActive
                                ? const Color(0xFF1565C0)
                                : const Color(0xFF6C6C6C),
                            fontSize: 10,
                            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}

// ─── DASHBOARD PAGE ─────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;
  int _bannerIndex = 0;
  late PageController _bannerCtrl;
  Timer? _bannerTimer;

  int _navIndex   = 0; // 0=Home, 1=Bug, 2=Tools, 3=Profile
  List<Map<String, dynamic>> _notifications = [];
  bool _hasNewNotif = false;
  int onlineUsers = 23;
  int activeConns = 2;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  Timer? _statsTimer;
  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;
  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  // For bug carousel
  late PageController _bugPageCtrl;
  double _currentBugPage = 0.0;

  bool _locationLoading = false;
  bool _locationGranted = false;

  String _prayerCity = 'Tangerang';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;

  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  String deviceModel = '';
  String deviceManufacturer = '';
  String androidVersion = '';
  String batteryLevel = '57%';
  String signalStrength = '93%';
  String ramUsage = '2.3G';
  String storageUsage = '86G';
  String sessionTime = '09:00';
  DateTime _loginTime = DateTime.now();
  Timer? _sessionTimer;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _bugPageCtrl = PageController();
    _bugPageCtrl.addListener(() {
      if (mounted) setState(() => _currentBugPage = _bugPageCtrl.page ?? 0.0);
    });

    _bannerCtrl = PageController();
    _bannerTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted && _bannerCtrl.hasClients) {
        final next = (_bannerIndex + 1) % 2;
        _bannerCtrl.animateToPage(next,
            duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
        setState(() => _bannerIndex = next);
      }
    });

    _initAndroidId();
    _initDeviceInfo();
    _loadProfileImage();
    _detectLocationAndFetchPrayer();
    _fetchRandomHadith();

    _sessionTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        final duration = DateTime.now().difference(_loginTime);
        final hours = duration.inHours;
        final minutes = duration.inMinutes.remainder(60);
        setState(() {
          sessionTime = '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}';
        });
      }
    });
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    _bannerTimer?.cancel();
    _bannerCtrl.dispose();
    _bugPageCtrl.dispose();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    _sessionTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  Future<void> _initDeviceInfo() async {
    final info = await DeviceInfoPlugin().androidInfo;
    if (mounted) {
      setState(() {
        deviceModel = info.model.isNotEmpty ? info.model : 'Unknown';
        deviceManufacturer = info.manufacturer.isNotEmpty ? info.manufacturer : 'Unknown';
        androidVersion = 'Android API ${info.version.sdkInt ?? 0}';
      });
    }
  }

  void _connectWS() {
    channel = WebSocketChannel.connect(Uri.parse('$baseUrl'));

    channel.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
        channel.sink.add(jsonEncode({'type': 'stats'}));
      }
      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConns = data['activeConnections'] ?? 0;
        });
      }
      if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Session invalid');
      }
      if (data['type'] == 'forceLogout' && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Logged out');
      }
    }, onError: (_) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try {
        channel.sink.add(jsonEncode({'type': 'stats'}));
      } catch (_) {}
    });
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh'  : timings['Fajr']    ?? '--:--',
        'Dzuhur' : timings['Dhuhr']   ?? '--:--',
        'Ashar'  : timings['Asr']     ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya'   : timings['Isha']    ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime  = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime  = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes     = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime  = nextTime;
        _prayerLoading   = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Tangerang';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Tangerang';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Tangerang';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Tangerang';

        setState(() {
          _prayerCity     = city;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kBlue,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Tangerang';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse('https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() { _hadith = json.decode(response.body); _hadithLoading = false; });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: kWhite, fontFamily: 'Orbitron', fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: kWhite),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: kWhite54),
            filled: true, fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded, color: kBlue),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: kWhite54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false;
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kBlue,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kBlue.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(color: kBlue.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  color: kBlue.withOpacity(0.08),
                  border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kBlue.withOpacity(0.2)),
                      child: const Icon(Icons.menu_book_rounded, color: kBlue, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('HADITH LENGKAP',
                            style: TextStyle(color: kWhite, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
                        Text(grade, style: const TextStyle(color: kBlue, fontSize: 11)),
                      ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: kWhite.withOpacity(0.08)),
                        child: const Icon(Icons.close_rounded, color: kWhite54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF18181B),
                          border: Border.all(color: kBorder.withOpacity(0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: kWhite, fontSize: 19, height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(width: 3, height: 18,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(2), color: kBlue)),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:', style: TextStyle(color: kBlue, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF111113),
                          border: Border.all(color: kBorder.withOpacity(0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(color: kWhite, fontSize: 14, fontStyle: FontStyle.italic, height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kBlue.withOpacity(0.5)),
                          color: kBlue.withOpacity(0.08),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.receipt_long_rounded, color: kBlue, size: 14),
                          const SizedBox(width: 6),
                          Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: const TextStyle(color: kBlue, fontSize: 12, fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('⚠️ Session Expired', style: TextStyle(color: kWhite)),
        content: Text(message, style: const TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: const Text('OK', style: TextStyle(color: kBlue)),
          ),
        ],
      ),
    );
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return _buildWhatsAppMenuPage();
      case 2:
        return ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos, username: username);
      case 3:
        return ProfilePage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      case 0:
      default:
        return _buildHomePage();
    }
  }

  // ─── NEW SWIPEABLE BUG MENU (CAROUSEL) ──────────────────────────────────
  Widget _buildWhatsAppMenuPage() {
    final menuOptions = [
      {
        'title': 'RIVERSIDE BUG',
        'subtitle': 'Bug tanpa custom',
        'description': 'Gunakan langsung tanpa custom delay dan loops',
        'icon': Icons.bug_report_rounded,
        'iconColor': const Color(0xFF1565C0),
        'gradient': [const Color(0xFF0A2472), const Color(0xFF1565C0)],
        'badge': 'RECOMMENDED',
        'badgeColor': const Color(0xFF1565C0),
        'features': ['Mudah digunakan', 'Function terbaru', 'All work gacor', 'RIVERSIDE BUG'],
        'onTap': () => Navigator.push(context, _slideRoute(HomePage(
          username: username, password: password, listBug: listBug,
          role: role, expiredDate: expiredDate, sessionKey: sessionKey,
        ))),
      },
      {
        'title': 'TOOLS',
        'subtitle': 'Alat bantu system',
        'description': 'Kumpulan tools OSINT dan utilities lengkap',
        'icon': Icons.build_circle_rounded,
        'iconColor': const Color(0xFF6366F1),
        'gradient': [const Color(0xFF1E1B4B), const Color(0xFF6366F1)],
        'badge': 'TOOLS',
        'badgeColor': const Color(0xFF6366F1),
        'features': ['OSINT tools', 'IP scanner', 'Port scanner', 'Utilities'],
        'onTap': () => Navigator.push(context, _slideRoute(ToolsPage(
          sessionKey: sessionKey, userRole: role, listDoos: listDoos, username: username,
        ))),
      },
      {
        'title': 'CUSTOM PAYLOAD',
        'subtitle': 'Custom delay & loops',
        'description': 'Setting custom delay dan jumlah loops sebelum kirim',
        'icon': Icons.tune_rounded,
        'iconColor': const Color(0xFFEC4899),
        'gradient': [const Color(0xFF831843), const Color(0xFFEC4899)],
        'badge': 'CUSTOM',
        'badgeColor': const Color(0xFFEC4899),
        'features': ['Custom delay', 'Custom loops', 'Target spesifik', 'Kontrol penuh'],
        'onTap': () => Navigator.push(context, _slideRoute(CustomPayloadPage(
          sessionKey: sessionKey, role: role, listBug: listBug,
          username: username, password: password, expiredDate: expiredDate,
        ))),
      },
      {
        'title': 'BUG GROUP',
        'subtitle': 'Kirim ke grup WhatsApp',
        'description': 'Target grup WhatsApp dengan berbagai bug pilihan',
        'icon': Icons.group_rounded,
        'iconColor': const Color(0xFF22C55E),
        'gradient': [const Color(0xFF14532D), const Color(0xFF22C55E)],
        'badge': 'GROUP',
        'badgeColor': const Color(0xFF22C55E),
        'features': ['Target grup WA', 'Multi sender', 'Bug pilihan', 'Efektif'],
        'onTap': () => Navigator.push(context, _slideRoute(BugGroupPage(
          sessionKey: sessionKey, role: role,
        ))),
      },
    ];

    return FadeTransition(
      opacity: _fadeAnim,
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(20),
            margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kBlue.withOpacity(0.15), Colors.transparent]),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBlue.withOpacity(0.3)),
            ),
            child: Row(children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: kBlue.withOpacity(0.15), shape: BoxShape.circle,
                  border: Border.all(color: kBlue.withOpacity(0.4)),
                ),
                child: const Icon(Icons.security_rounded, color: kBlue, size: 24),
              ),
              const SizedBox(width: 14),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('PILIH MENU BUG', style: TextStyle(
                  color: kWhite, fontFamily: 'Orbitron', fontWeight: FontWeight.w900,
                  fontSize: 14, letterSpacing: 1.5,
                )),
                Text('Geser kiri/kanan untuk memilih metode',
                  style: TextStyle(color: kWhite54, fontSize: 12)),
              ]),
            ]),
          ),
          // Carousel
          Expanded(
            child: PageView.builder(
              controller: _bugPageCtrl,
              itemCount: menuOptions.length,
              onPageChanged: (index) {
                if (mounted) setState(() => _currentBugPage = index.toDouble());
              },
              itemBuilder: (context, index) {
                final opt = menuOptions[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  child: GestureDetector(
                    onTap: opt['onTap'] as VoidCallback,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: (opt['gradient'] as List).cast<Color>(),
                          begin: Alignment.topLeft, end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [BoxShadow(
                          color: (opt['iconColor'] as Color).withOpacity(0.35),
                          blurRadius: 20, offset: const Offset(0, 8),
                        )],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Container(
                                width: 56, height: 56,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                child: Icon(opt['icon'] as IconData, color: Colors.white, size: 28),
                              ),
                              const SizedBox(width: 16),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(opt['title'] as String, style: const TextStyle(
                                  color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900,
                                  fontSize: 18, letterSpacing: 1,
                                )),
                                Text(opt['subtitle'] as String, style: TextStyle(
                                  color: Colors.white.withOpacity(0.7), fontSize: 14,
                                )),
                              ])),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(opt['badge'] as String, style: const TextStyle(
                                  color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                )),
                              ),
                            ]),
                            const SizedBox(height: 16),
                            Text(opt['description'] as String, style: TextStyle(
                              color: Colors.white.withOpacity(0.7), fontSize: 14, height: 1.5,
                            )),
                            const SizedBox(height: 16),
                            Wrap(
                              spacing: 10, runSpacing: 8,
                              children: (opt['features'] as List<String>).map((f) => Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.25),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.white.withOpacity(0.15)),
                                ),
                                child: Text(f, style: TextStyle(
                                  color: Colors.white.withOpacity(0.9), fontSize: 12,
                                )),
                              )).toList(),
                            ),
                            const Spacer(),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text('BUKA', style: TextStyle(
                                      color: Colors.white.withOpacity(0.9), fontFamily: 'Orbitron',
                                      fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 1,
                                    )),
                                    const SizedBox(width: 8),
                                    Icon(Icons.arrow_forward_ios_rounded, color: Colors.white.withOpacity(0.9), size: 14),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          // Dots indicator
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(menuOptions.length, (index) {
                final isActive = _currentBugPage.round() == index;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: isActive ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: isActive ? kBlue : Colors.white24,
                  ),
                );
              }),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildInstagramStories() {
    final stories = [
      {'name': 'Cerita Saya', 'isAdd': true},
      {'name': 'ImArkxnatta', 'isAdd': false},
      {'name': 'RIVERSIDE', 'isAdd': false},
      {'name': 'Supernova', 'isAdd': false},
      {'name': 'Arkxcode', 'isAdd': false},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: SizedBox(
        height: 90,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          itemCount: stories.length,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (ctx, i) {
            final story = stories[i];
            final isAdd = story['isAdd'] as bool;
            final name = story['name'] as String;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  children: [
                    Container(
                      width: 62, height: 62,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isAdd
                            ? null
                            : LinearGradient(
                                colors: [
                                  const Color(0xFFF58529),
                                  const Color(0xFFDD2A7B),
                                  const Color(0xFF8134AF),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                        border: isAdd
                            ? Border.all(color: kWhite24, width: 2)
                            : null,
                        color: isAdd ? kCard : null,
                      ),
                      child: isAdd
                          ? const Icon(Icons.add_circle_rounded, color: kBlue, size: 60)
                          : Padding(
                              padding: const EdgeInsets.all(2.5),
                              child: CircleAvatar(
                                backgroundColor: kCardAlt,
                                backgroundImage: const AssetImage('assets/images/logo.png'),
                                onBackgroundImageError: (_, __) => null,
                                child: Text(
                                  name.isNotEmpty ? name[0].toUpperCase() : '?',
                                  style: const TextStyle(color: kWhite, fontSize: 20, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                    ),
                    if (isAdd)
                      Positioned(
                        bottom: 0, right: 0,
                        child: Container(
                          width: 18, height: 18,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: kBlue,
                          ),
                          child: const Icon(Icons.add, color: Colors.white, size: 14),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  name,
                  style: const TextStyle(
                    color: kWhite,
                    fontSize: 10,
                    fontWeight: FontWeight.w400,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildInstagramStories(),
            const SizedBox(height: 6),
            _buildBannerVideo(),
            const SizedBox(height: 14),
            _buildWelcomeCard(),
            const SizedBox(height: 14),
            _buildSystemInfoCard(),
            const SizedBox(height: 14),
            _buildLatestUpdates(),
            const SizedBox(height: 14),
            _buildPrayerSection(),
            const SizedBox(height: 14),
            _buildHadithSection(),
            const SizedBox(height: 24),
            Center(
              child: Text('RIVERSIDE',
                style: TextStyle(
                  color: kWhite.withOpacity(0.12),
                  fontSize: 13, letterSpacing: 4,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildBannerVideo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: SizedBox(
              height: 190, width: double.infinity,
              child: PageView.builder(
                controller: _bannerCtrl,
                onPageChanged: (i) => setState(() => _bannerIndex = i),
                itemCount: 2,
                itemBuilder: (ctx, i) => Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      i == 0 ? 'assets/images/ornes_1.png' : 'assets/images/ornes_2.png',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: const Color(0xFF09090B),
                        child: Center(child: Icon(Icons.image_rounded, color: kBlue, size: 48)),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.black.withOpacity(0.6), Colors.transparent, Colors.black.withOpacity(0.3)],
                          begin: Alignment.bottomCenter, end: Alignment.topCenter,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.cloud_outlined, color: kWhite54, size: 16),
              const SizedBox(width: 8),
              const Text('RIVERSIDE', style: TextStyle(color: kWhite, fontSize: 14, fontFamily: 'Orbitron', letterSpacing: 2, fontWeight: FontWeight.bold)),
              const SizedBox(width: 8),
              const Icon(Icons.cloud_outlined, color: kWhite54, size: 16),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(2, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: _bannerIndex == i ? 20 : 6, height: 6,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                color: _bannerIndex == i ? kBlue : kWhite24,
              ),
            )),
          ),
        ],
      ),
    );
  }

  // ─── WELCOME CARD WITH BACKGROUND IMAGE ──────────────────────────────────
  Widget _buildWelcomeCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.8)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.8), blurRadius: 40, offset: const Offset(0, 16)),
          ],
          image: const DecorationImage(
            image: AssetImage('assets/images/user_card.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                ScaleTransition(
                  scale: _pulseAnim,
                  child: Container(
                    width: 58, height: 58,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(colors: [Color(0xFF1565C0), Color(0xFF0D3B8E)]),
                      boxShadow: [BoxShadow(color: kBlue.withOpacity(0.5), blurRadius: 24, spreadRadius: 2)],
                    ),
                    child: _profileImage != null
                        ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover, width: 58, height: 58))
                        : ClipOval(child: Image.asset('assets/images/logo.png', fit: BoxFit.cover, width: 58, height: 58,
                            errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: kWhite, size: 28))),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Halo,',
                          style: TextStyle(color: kWhite54, fontSize: 12, fontFamily: 'Orbitron')),
                      Text(username,
                          style: const TextStyle(
                            color: kWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: const Color(0xFF1565C0).withOpacity(0.5)),
                          color: const Color(0xFF1565C0).withOpacity(0.08),
                        ),
                        child: Text(role.toUpperCase(),
                            style: const TextStyle(
                              color: Color(0xFF1565C0), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: kBlue.withOpacity(0.1),
                    border: Border.all(color: kBlue.withOpacity(0.3)),
                  ),
                  child: ClipOval(
                    child: Image.asset('assets/images/mobil.png', fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(Icons.directions_car_rounded, color: kBlue, size: 24)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: const Color(0xFF1565C0).withOpacity(0.3)),
                color: const Color(0xFF1565C0).withOpacity(0.04),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _AnimatedDot(color: const Color(0xFF1565C0)),
                  const SizedBox(width: 10),
                  const Text('RIVERSIDE DASHBOARD',
                      style: TextStyle(
                        color: Color(0xFF1565C0), fontSize: 11, fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron', letterSpacing: 1.5)),
                  const SizedBox(width: 10),
                  _AnimatedDot(color: const Color(0xFF1565C0)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _buildCircleStatItem(
                    icon: Icons.people_alt_rounded,
                    value: '$onlineUsers',
                    label: 'Online Users',
                    color: const Color(0xFFFFD700)),
                _buildStatDivider(),
                _buildCircleStatItem(
                    icon: Icons.link_rounded,
                    value: '$activeConns',
                    label: 'Total Owner',
                    color: const Color(0xFFCE93D8)),
                _buildStatDivider(),
                _buildCircleStatItem(
                    icon: Icons.calendar_month_rounded,
                    value: expiredDate.length > 10 ? expiredDate.substring(0, 10) : expiredDate,
                    label: 'Expiration',
                    color: const Color(0xFFFFAB40)),
              ],
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerLeft,
              child: ScaleTransition(
                scale: _pulseAnim,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.5)),
                    color: const Color(0xFFFFD700).withOpacity(0.08),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _AnimatedDot(color: const Color(0xFFFFD700)),
                      const SizedBox(width: 6),
                      const Text('LIVE',
                          style: TextStyle(
                              color: Color(0xFFFFD700), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCircleStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 62, height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.12),
              border: Border.all(color: color.withOpacity(0.5), width: 2),
              boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 22, spreadRadius: 2)],
            ),
            child: Center(child: Icon(icon, color: color, size: 28)),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  color: kWhite, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Orbitron')),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: kWhite54, fontSize: 9), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildStatDivider() =>
      Container(width: 1, height: 60, color: kBorder.withOpacity(0.5));

  Widget _buildSystemInfoCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.8)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.8), blurRadius: 40, offset: const Offset(0, 16)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('SYSTEM',
                style: TextStyle(
                  color: kWhite, fontSize: 14, fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron', letterSpacing: 1.5,
                )),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.devices_rounded, color: kWhite54, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${deviceManufacturer.isNotEmpty ? deviceManufacturer : 'vivo'} ${deviceModel.isNotEmpty ? deviceModel : '1915'}',
                    style: const TextStyle(color: kWhite, fontSize: 14, fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 8,
              childAspectRatio: 3.5,
              children: [
                _buildSystemInfoItem(Icons.battery_full_rounded, 'Charging', batteryLevel),
                _buildSystemInfoItem(Icons.signal_cellular_alt_rounded, 'Signal', signalStrength),
                _buildSystemInfoItem(Icons.memory_rounded, 'RAM', ramUsage),
                _buildSystemInfoItem(Icons.storage_rounded, 'Storage', storageUsage),
              ],
            ),
            const SizedBox(height: 16),
            Column(
              children: [
                _buildPlayerInfoRow(Icons.people_alt_rounded, 'Online users', '$onlineUsers aktif'),
                _buildPlayerInfoRow(Icons.link_rounded, 'Connections', '$activeConns active'),
                _buildPlayerInfoRow(Icons.timer_rounded, 'Session time', sessionTime),
                _buildPlayerInfoRow(Icons.key_rounded, 'Session key', sessionKey),
                _buildPlayerInfoRow(Icons.calendar_month_rounded, 'Access until', expiredDate),
                _buildPlayerInfoRow(Icons.android_rounded, 'System', androidVersion),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSystemInfoItem(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: kBg,
        border: Border.all(color: kBorder.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          Icon(icon, color: kWhite54, size: 14),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: kWhite54, fontSize: 11)),
          const Spacer(),
          Text(value, style: const TextStyle(color: kWhite, fontSize: 12, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildPlayerInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: kWhite54, size: 14),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: kWhite54, fontSize: 11)),
          const Spacer(),
          Text(value, style: const TextStyle(color: kWhite, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp,
        bgIcon: FontAwesomeIcons.whatsapp,
        title: 'Manage Sender',
        subtitle: 'Manage your active sender',
        gradient: [const Color(0xFF9B59B6), const Color(0xFF2C0845)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)),
        ).then((_) {
          if (mounted && _newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        }),
      ),
      _QuickActionData(
        icon: Icons.chat_bubble_rounded,
        bgIcon: Icons.chat_bubble_rounded,
        title: 'Chat Room',
        subtitle: 'Global chat room',
        gradient: [const Color(0xFF0D7377), const Color(0xFF14FFEC)],
        onTap: () => Navigator.push(context, _slideRoute(ChatRoomPage(username: username))),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.telegram,
        bgIcon: FontAwesomeIcons.telegram,
        title: 'Join Channel',
        subtitle: 'Info Channel',
        gradient: [const Color(0xFF0077B6), const Color(0xFF29B6F6)],
        onTap: () => _openUrl('https://t.me/EvoraProject'),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran,
        bgIcon: FontAwesomeIcons.bookQuran,
        title: 'Al Quran',
        subtitle: 'Baca Al-Quran & Doa',
        gradient: [const Color(0xFF1A4731), const Color(0xFF22C55E)],
        onTap: () => Navigator.push(context, _slideRoute(AlQuranPage())),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.tv,
        bgIcon: FontAwesomeIcons.tv,
        title: 'Anime',
        subtitle: 'Discover & Watch Anime',
        gradient: [const Color(0xFF4A0020), const Color(0xFFFF1744)],
        onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
      ),
      _QuickActionData(
        icon: Icons.sports_esports_rounded,
        bgIcon: Icons.sports_esports_rounded,
        title: 'Game Ular',
        subtitle: 'Mini game seru',
        gradient: [const Color(0xFF1A3A1A), const Color(0xFF4CAF50)],
        onTap: () => Navigator.push(context, _slideRoute(const SnakeGame())),
      ),
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: const Color(0xFFFFD700).withOpacity(0.12),
                  border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.3)),
                ),
                child: const Icon(Icons.bolt_rounded, color: Color(0xFFFFD700), size: 22),
              ),
              const SizedBox(width: 12),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('CONNECT WITH RIVERSIDE',
                      style: TextStyle(
                        color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                        fontFamily: 'Orbitron', letterSpacing: 1)),
                  Text('Selalu nantikan project terbaru dari @ImArkxnatta',
                      style: TextStyle(color: kWhite54, fontSize: 12)),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color(0xFFFFD700).withOpacity(0.10),
                  border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.35)),
                ),
                child: Row(children: [
                  Container(
                      width: 7, height: 7,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFFFD700))),
                  const SizedBox(width: 5),
                  const Text('RIVERSIDE',
                      style: TextStyle(color: Color(0xFFFFD700), fontSize: 11, fontWeight: FontWeight.bold)),
                ]),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: actions.length,
            onPageChanged: (index) {
              if (mounted) setState(() => _currentQaPage = index.toDouble());
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _buildQuickActionCard(actions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: isActive ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: isActive ? const Color(0xFFFFD700) : Colors.white24,
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
              colors: action.gradient,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          boxShadow: [
            BoxShadow(
                color: action.gradient.first.withOpacity(0.25),
                blurRadius: 24, offset: const Offset(0, 10))
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -12, bottom: -12,
              child: Icon(action.bgIcon, color: Colors.white.withOpacity(0.05), size: 110),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50, height: 50,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white.withOpacity(0.15)),
                    child: Icon(action.icon, color: kWhite, size: 24),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.white.withOpacity(0.15)),
                      child: const Text('Tap →',
                          style: TextStyle(color: kWhite, fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(action.title,
                      style: const TextStyle(
                        color: kWhite, fontWeight: FontWeight.bold, fontSize: 17, fontFamily: 'Orbitron')),
                  const SizedBox(height: 4),
                  Text(action.subtitle,
                      style: TextStyle(color: kWhite.withOpacity(0.8), fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              const Icon(Icons.dashboard_customize_rounded, color: kBlue, size: 22),
              const SizedBox(width: 8),
              const Text('BERITA TERKINI',
                  style: TextStyle(
                    color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                    fontFamily: 'Orbitron', letterSpacing: 1)),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: kBlue.withOpacity(0.15),
                    border: Border.all(color: kBlue.withOpacity(0.4)),
                  ),
                  child: Text('${newsList.length} Updates',
                      style: const TextStyle(
                          color: kBlue, fontSize: 11, fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCardHorizontal(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 120,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: kCard,
                  border: Border.all(color: kBorder.withOpacity(0.4))),
              child: const Center(
                  child: Text('No updates available', style: TextStyle(color: kWhite54))),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl   = item['image']?.toString() ?? '';
    final title    = item['title']?.toString() ?? 'No Title';
    final date     = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: kCard,
        border: Border.all(color: kBorder.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 6))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110, width: double.infinity, color: kCardAlt,
                  child: imgUrl.isNotEmpty
                      ? Image.network(imgUrl, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Center(
                              child: Icon(Icons.image_not_supported, color: kWhite54, size: 30)))
                      : const Center(
                          child: Icon(Icons.article_rounded, color: kWhite54, size: 30)),
                ),
                Positioned(
                  top: 8, right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black.withOpacity(0.65),
                      border: Border.all(color: kBlue.withOpacity(0.7)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle_notifications_rounded, color: kBlue, size: 10),
                        SizedBox(width: 3),
                        Text('NEW',
                            style: TextStyle(
                                color: kBlue, fontSize: 9, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Text(title,
                style: const TextStyle(
                  color: kWhite, fontSize: 16, fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron', height: 1.3),
                maxLines: 2, overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded, color: kWhite54, size: 11),
                const SizedBox(width: 4),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                        date.length > 10 ? date.substring(0, 10) : date,
                        style: const TextStyle(color: kWhite54, fontSize: 10)),
                  ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: kBlue.withOpacity(0.18)),
                  child: const Icon(Icons.arrow_forward_ios_rounded, color: kBlue, size: 9),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF2D2D3D),
      const Color(0xFF3A3A4A),
      const Color(0xFF353545),
      const Color(0xFF252535),
      const Color(0xFF18181B),
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1C1C1E),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF3A3A3C).withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: const Color(0xFF48484A).withOpacity(0.3),
                    border: Border.all(color: const Color(0xFF48484A).withOpacity(0.5)),
                  ),
                  child: const Center(child: Icon(Icons.mosque, color: Color(0xFF8E8E93), size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('JADWAL SHOLAT',
                          style: TextStyle(
                            color: Color(0xFFE5E5EA),
                            fontWeight: FontWeight.bold, fontSize: 15,
                            fontFamily: 'Orbitron', letterSpacing: 1)),
                      Text(_prayerCity,
                          style: const TextStyle(color: Color(0xFF636366), fontSize: 12)),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _locationLoading ? null : _detectLocationAndFetchPrayer,
                  child: Container(
                    width: 38, height: 38,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _locationGranted
                          ? const Color(0xFF48484A).withOpacity(0.3)
                          : const Color(0xFF2C2C2E).withOpacity(0.5),
                      border: Border.all(
                        color: _locationGranted
                            ? const Color(0xFF48484A).withOpacity(0.6)
                            : const Color(0xFF3A3A3C).withOpacity(0.3),
                      ),
                    ),
                    child: _locationLoading
                        ? const Padding(
                            padding: EdgeInsets.all(10),
                            child: CircularProgressIndicator(color: Color(0xFF8E8E93), strokeWidth: 2),
                          )
                        : Icon(
                            _locationGranted
                                ? Icons.my_location_rounded
                                : Icons.location_searching_rounded,
                            color: _locationGranted ? const Color(0xFF8E8E93) : const Color(0xFF48484A),
                            size: 18,
                          ),
                  ),
                ),
                GestureDetector(
                  onTap: _showChangeCityDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: const Color(0xFF3A3A3C),
                    ),
                    child: const Row(children: [
                      Icon(Icons.edit_location_alt_rounded, color: Color(0xFFE5E5EA), size: 14),
                      SizedBox(width: 5),
                      Text('GANTI',
                          style: TextStyle(
                              color: Color(0xFFE5E5EA), fontSize: 12, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            if (_nextPrayerLabel.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: const Color(0xFF2C2C2E),
                  border: Border.all(color: const Color(0xFF48484A).withOpacity(0.6)),
                ),
                child: Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: _AnimatedDot(color: const Color(0xFF8E8E93), size: 10),
                    ),
                    const SizedBox(width: 10),
                    Text('Menuju $_nextPrayerLabel : $_nextPrayerTime',
                        style: const TextStyle(
                          color: Color(0xFFE5E5EA), fontSize: 13, fontWeight: FontWeight.w600,
                          fontFamily: 'Orbitron')),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFF636366).withOpacity(0.5)),
                      ),
                      child: const Text('NYTHER',
                          style: TextStyle(color: Color(0xFF636366), fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 14),

            if (_prayerLoading)
              const Center(child: CircularProgressIndicator(color: Color(0xFF8E8E93), strokeWidth: 2))
            else
              SizedBox(
                height: 118,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: prayerKeys.length,
                  itemBuilder: (ctx, i) {
                    final key   = prayerKeys[i];
                    final time  = _prayerTimes[key] ?? '--:--';
                    final color = prayerColors[i];
                    final icon  = prayerIcons[i];
                    final isNext = key == _nextPrayerLabel;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      margin: EdgeInsets.only(right: 10, bottom: isNext ? 0 : 6, top: isNext ? 0 : 6),
                      width: 105,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: color,
                        boxShadow: [
                          BoxShadow(
                              color: color.withOpacity(isNext ? 0.65 : 0.3),
                              blurRadius: isNext ? 18 : 8, offset: const Offset(0, 4))
                        ],
                        border: isNext
                            ? Border.all(color: const Color(0xFF636366).withOpacity(0.8), width: 1.5)
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: const Color(0xFFE5E5EA), size: 24),
                            const SizedBox(height: 5),
                            Text(key.toUpperCase(),
                                style: const TextStyle(
                                    color: Color(0xFF8E8E93), fontSize: 9,
                                    fontWeight: FontWeight.bold, letterSpacing: 0.8)),
                            const SizedBox(height: 5),
                            Text(time,
                                style: const TextStyle(
                                    color: Color(0xFFE5E5EA), fontSize: 19,
                                    fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kBorder.withOpacity(0.5)),
          ),
          child: const Center(child: CircularProgressIndicator(color: kBlue, strokeWidth: 2)),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
    final indo   = _hadith?['data']?['text']?['id'] ??
        'Sesungguhnya setiap amalan tergantung pada niatnya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade  = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard, borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: kBlue.withOpacity(0.18)),
                  child: const Center(child: Icon(Icons.menu_book_rounded, color: kBlue, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('HADITH OF THE DAY',
                        style: TextStyle(
                          color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                          fontFamily: 'Orbitron', letterSpacing: 0.5)),
                    const SizedBox(height: 2),
                    Text('$grade · Tap card to read full',
                        style: const TextStyle(color: kWhite54, fontSize: 11)),
                  ]),
                ),
              ],
            ),
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF18181B),
                      border: Border.all(color: kBorder.withOpacity(0.3)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                        style: const TextStyle(color: kWhite, fontSize: 17, height: 2.0)),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14), color: const Color(0xFF111113)),
                    child: Text(indo,
                        style: const TextStyle(
                          color: kWhite54, fontSize: 12, fontStyle: FontStyle.italic, height: 1.7),
                        maxLines: 3, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: kBlue.withOpacity(0.45)),
                    color: kBlue.withOpacity(0.07),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.receipt_long_rounded, color: kBlue, size: 13),
                    const SizedBox(width: 5),
                    Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: const TextStyle(
                            color: kBlue, fontSize: 11, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: kWhite54.withOpacity(0.3)),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.touch_app_rounded, color: kWhite54, size: 14),
                      SizedBox(width: 4),
                      Text('Tap card', style: TextStyle(color: kWhite54, fontSize: 11)),
                    ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ──────────────────── BUILD ──────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      extendBodyBehindAppBar: false,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset('assets/images/background.jpg', fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox()),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.75)),
          ),
          _buildBackgroundGrid(),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            transitionBuilder: (child, anim) =>
                FadeTransition(opacity: anim, child: child),
            child: KeyedSubtree(
              key: ValueKey(_navIndex),
              child: _buildCurrentPage(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBackgroundGrid() {
    return CustomPaint(
      size: Size.infinite,
      painter: _GridPatternPainter(
        gridColor: kBlue.withOpacity(0.04),
        lineColor: kPink.withOpacity(0.02),
        spacing: 35,
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: kBg.withOpacity(0.95),
      elevation: 0,
      iconTheme: const IconThemeData(color: kWhite),
      titleSpacing: 0,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.4))),
        ),
      ),
      title: Row(
        children: [
          const SizedBox(width: 8),
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: kBlue.withOpacity(0.4)),
              color: kBlue.withOpacity(0.1),
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, width: 36, height: 36, fit: BoxFit.cover)
                  : Image.asset('assets/images/logo.png', width: 36, height: 36, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: kBlue, size: 20)),
            ),
          ),
        ],
      ),
      actions: [
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            )),
          ).then((_) {
            _loadProfileImage();
            if (mounted && _newsPageCtrl.hasClients) {
              setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
              _newsPageCtrl.jumpToPage(0);
            }
          }),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(username,
                  style: const TextStyle(
                      color: kWhite, fontSize: 13, fontWeight: FontWeight.bold)),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(role.toUpperCase(),
                      style: const TextStyle(
                          color: kWhite54, fontSize: 10, fontFamily: 'Orbitron')),
                  const SizedBox(width: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: Colors.red.withOpacity(0.2),
                        border: Border.all(color: Colors.red.withOpacity(0.4))),
                    child: Text('Exp: $expiredDate',
                        style: const TextStyle(
                            color: Colors.red, fontSize: 9, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            )),
          ),
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.red.withOpacity(0.5), width: 2),
              color: Colors.red.withOpacity(0.2),
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : const Icon(FontAwesomeIcons.userAstronaut, color: Colors.redAccent, size: 20),
            ),
          ),
        ),
        const SizedBox(width: 4),
        GestureDetector(
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Icon(Icons.headset_mic_outlined, color: kWhite, size: 24),
          ),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ─── BOTTOM NAV (4 items) ──────────────────────────────────────────────
  Widget _buildBottomNav() {
    return _AnimatedNotchBottomNav(
      currentIndex: _navIndex,
      onTap: _onNavTap,
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset('assets/images/ornes_1.png', fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: Colors.black)),
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.85)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kBlue.withOpacity(0.6), width: 2.5),
                            boxShadow: [BoxShadow(color: kBlue.withOpacity(0.3), blurRadius: 14, spreadRadius: 2)],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : const Icon(FontAwesomeIcons.userAstronaut, size: 38, color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(),
                            style: const TextStyle(color: kBlue, fontSize: 12, letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kBg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  _buildDrawerItem(
                    icon: Icons.notifications_rounded,
                    label: 'Notifikasi',
                    badge: _hasNewNotif,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(NotificationPage(
                        notifications: _notifications,
                        role: role,
                        onClear: () => setState(() {
                          _notifications.clear();
                          _hasNewNotif = false;
                        }),
                      ))).then((_) => setState(() => _hasNewNotif = false));
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.info_outline_rounded,
                    label: 'Informasi App',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(InfoPage(sessionKey: sessionKey)));
                    },
                  ),
                  const Divider(color: Color(0xFF27272A), indent: 16, endIndent: 16),
                  if (role.toLowerCase() == 'reseller')
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Seller Page',
                        onTap: () => _onDrawerNav(1)),
                  if (role.toLowerCase() == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Page',
                        onTap: () => _onDrawerNav(2)),
                  if (role.toLowerCase() == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Page',
                        onTap: () => _onDrawerNav(3)),
                  if (role.toLowerCase() == 'developer')
                    _buildDrawerItem(
                        icon: Icons.developer_mode_rounded,
                        label: 'Developer Panel',
                        color: const Color(0xFFEC4899),
                        onTap: () => _onDrawerNav(3)),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))).then((_) {
                        if (mounted && _newsPageCtrl.hasClients) {
                          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
                          _newsPageCtrl.jumpToPage(0);
                        }
                      });
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
    bool badge = false,
    Color? color,
  }) {
    final iconColor = isLogout ? Colors.redAccent : (color ?? kBlue);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.08) : kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout ? Colors.red.withOpacity(0.3) : kBorder.withOpacity(0.4)),
      ),
      child: ListTile(
        leading: Stack(
          clipBehavior: Clip.none,
          children: [
            Icon(icon, color: iconColor, size: 20),
            if (badge)
              Positioned(top: -4, right: -4,
                child: Container(
                  width: 8, height: 8,
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                ),
              ),
          ],
        ),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, color: kWhite24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

// ─── Quick Action Data ─────────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

// ─── Slide Route ──────────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

// ─── NewsMedia ────────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }
  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return const Center(child: CircularProgressIndicator(color: kBlue, strokeWidth: 2));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Container(color: kCard, child: const Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}