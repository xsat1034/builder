class _Logger {
  final String name;
  _Logger(this.name);

  void log(String message, {bool addToBuffer = false}) {
    // ignore: avoid_print
    print('[$name] $message');
  }
}

class Logs {
  static final _Logger app = _Logger('APP');

  static Future<void> writeAllLogs() async {
    // no-op stub
  }
}
