class AppVersion {
  static String current = '1.0.0';

  static void init() {
    // no-op stub
  }
}
