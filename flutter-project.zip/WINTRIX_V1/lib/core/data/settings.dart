class UserSettings {
  bool? darkMode;
  bool? amoledBackground;
  bool? materialTheme;
  bool? enableDiscordPresence;
  bool? useFramelessWindow;

  UserSettings({
    this.darkMode = true,
    this.amoledBackground = false,
    this.materialTheme = false,
    this.enableDiscordPresence = false,
    this.useFramelessWindow = true,
  });
}

class Settings {
  Future<UserSettings> getSettings() async {
    return UserSettings();
  }
}
