class AnimeOnsen {
  Future<void> checkAndUpdateToken() async {
    // no-op stub
  }
}
