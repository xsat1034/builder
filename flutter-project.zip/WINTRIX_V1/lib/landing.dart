// landing.dart
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // --- RIVERSIDE NAVY BLUE THEME ---
  static const Color bgDark = Color(0xFF0A0F26);
  static const Color accentBlue = Color(0xFF42A5F5);
  static const Color darkBlue = Color(0xFF1565C0);
  static const Color softBlue = Color(0xFF64B5F6);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);
  static const Color glassPrimary = Color(0x1AFFFFFF);
  static const Color glassSecondary = Color(0x0DFFFFFF);

  LinearGradient get blueGradient => const LinearGradient(
        colors: [Color(0xFF42A5F5), Color(0xFF1565C0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Stack(
        children: [
          // ========== BACKGROUND VIDEO ==========
          Positioned.fill(
            child: Image.asset(
              "assets/images/login.png",
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.topCenter,
                      radius: 1.5,
                      colors: [accentBlue.withOpacity(0.15), bgDark, bgDark],
                      stops: const [0.0, 0.4, 1.0],
                    ),
                  ),
                );
              },
            ),
          ),

          // Dark overlay supaya teks tetap terbaca di atas background
          Positioned.fill(
            child: Container(color: bgDark.withOpacity(0.35)),
          ),

          // ========== CONTENT ==========
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      children: [
                        const SizedBox(height: 24),

                        // ========== LOGO & TITLE ==========
                        _buildHeader(),

                        const SizedBox(height: 32),

                        // ========== FITUR CARD (3 CARD) ==========
                        _buildFeatureRow(),

                        const SizedBox(height: 24),

                        // ========== TOMBOL MASUK ==========
                        _buildMasukButton(),

                        const SizedBox(height: 14),

                        // ========== TOMBOL BELI AKSES ==========
                        _buildBeliAksesButton(),

                        const SizedBox(height: 14),

                        // ========== TOMBOL HUBUNGI SUPPORT ==========
                        _buildSupportButton(),

                        const SizedBox(height: 24),

                        // ========== CONTACT SECTION ==========
                        _buildContactSection(),

                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== HEADER ====================
  Widget _buildHeader() {
    return Column(
      children: [
        // Logo image di atas judul
        TweenAnimationBuilder(
          duration: const Duration(milliseconds: 600),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double value, child) {
            return Opacity(
              opacity: value,
              child: Transform.scale(scale: value, child: child),
            );
          },
          child: SizedBox(
            width: 200,
            height: 200,
            child: Image.asset(
              "assets/images/reze.png",
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: blueGradient,
                    boxShadow: [
                      BoxShadow(
                        color: accentBlue.withOpacity(0.5),
                        blurRadius: 30,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.sailing_rounded, size: 70, color: primaryWhite),
                );
              },
            ),
          ),
        ),

        const SizedBox(height: 8),

        // Title APK RIVERSIDE - FOR YOU dengan ShaderMask
        ShaderMask(
          shaderCallback: (bounds) => blueGradient.createShader(bounds),
          child: const Text(
            "APK RIVERSIDE · FOR YOU",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: primaryWhite,
              letterSpacing: 1.5,
            ),
          ),
        ),

        const SizedBox(height: 8),

        // Subtitle
        Text(
          "APK Terbaru dengan fitur lengkap",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 13,
            color: softGrey,
            letterSpacing: 0.4,
          ),
        ),
      ],
    );
  }

  // ==================== FEATURE ROW (3 CARD) ====================
  Widget _buildFeatureRow() {
    return Row(
      children: [
        Expanded(
          child: _buildFeatureCard(
            icon: Icons.smartphone_rounded,
            title: "TERMUX",
            desc: "install di HP, langsung jalan",
            delay: 0,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildFeatureCard(
            icon: Icons.dns_rounded,
            title: "VPS",
            desc: "Server 24/7 stabil",
            delay: 100,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildFeatureCard(
            icon: Icons.explore_rounded,
            title: "UBOT",
            desc: "Bot per user",
            delay: 200,
          ),
        ),
      ],
    );
  }

  Widget _buildFeatureCard({
    required IconData icon,
    required String title,
    required String desc,
    required int delay,
  }) {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 400 + delay),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        height: 140,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: glassPrimary,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: primaryWhite.withOpacity(0.10)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: primaryWhite.withOpacity(0.9), size: 24),
            const SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: primaryWhite,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              desc,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 9.5,
                color: softGrey,
                height: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== MASUK BUTTON ====================
  Widget _buildMasukButton() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 500),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: GestureDetector(
          onTap: () {
            Navigator.pushNamed(context, "/login");
          },
          child: Container(
            decoration: BoxDecoration(
              gradient: blueGradient,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: accentBlue.withOpacity(0.4),
                  blurRadius: 16,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: const Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.login_rounded, color: primaryWhite, size: 20),
                  SizedBox(width: 12),
                  Text(
                    "MASUK",
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: primaryWhite,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==================== BELI AKSES BUTTON ====================
  Widget _buildBeliAksesButton() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: GestureDetector(
          onTap: () => _openUrl("https://t.me/Arkxcode"),
          child: Container(
            decoration: BoxDecoration(
              color: glassSecondary,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: primaryWhite.withOpacity(0.12), width: 1.2),
            ),
            child: const Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.shopping_bag_rounded, color: primaryWhite, size: 18),
                  SizedBox(width: 12),
                  Text(
                    "BELI AKSES",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: primaryWhite,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==================== HUBUNGI SUPPORT BUTTON ====================
  Widget _buildSupportButton() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 700),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: GestureDetector(
          onTap: () => _openUrl("https://t.me/Arkxcode"),
          child: Container(
            decoration: BoxDecoration(
              color: glassSecondary,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: primaryWhite.withOpacity(0.12), width: 1.2),
            ),
            child: const Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.headset_mic_rounded, color: primaryWhite, size: 18),
                  SizedBox(width: 12),
                  Text(
                    "HUBUNGI SUPPORT",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: primaryWhite,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==================== CONTACT SECTION ====================
  Widget _buildContactSection() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 800),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
        decoration: BoxDecoration(
          color: glassSecondary,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: primaryWhite.withOpacity(0.08)),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildContactIcon(
                  icon: FontAwesomeIcons.telegram,
                  label: "Telegram",
                  url: "https://t.me/Arkxcode",
                ),
                const SizedBox(width: 40),
                _buildContactIcon(
                  icon: FontAwesomeIcons.tiktok,
                  label: "TikTok",
                  url: "https://tiktok.com/",
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              "© 2026 RIVERSIDE",
              style: TextStyle(
                color: softGrey.withOpacity(0.6),
                fontSize: 11,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactIcon({
    required IconData icon,
    required String label,
    required String url,
  }) {
    return GestureDetector(
      onTap: () => _openUrl(url),
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: glassPrimary,
              border: Border.all(color: primaryWhite.withOpacity(0.15)),
            ),
            child: FaIcon(icon, color: primaryWhite.withOpacity(0.9), size: 22),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: softGrey,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
