import 'package:otax/ui/theme/types.dart';

abstract class ThemeItem {
  int get id;
  String get name;
  AnimeStreamTheme get theme;
  AnimeStreamTheme get lightVariant;
}

List<ThemeItem> availableThemes = [];
