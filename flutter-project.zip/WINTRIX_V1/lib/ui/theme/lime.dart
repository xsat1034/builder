import 'package:flutter/material.dart';
import 'package:otax/ui/theme/themes.dart';
import 'package:otax/ui/theme/types.dart';

class LimeZest extends ThemeItem {
  @override
  int get id => 1;

  @override
  String get name => 'Lime Zest';

  @override
  AnimeStreamTheme get theme => AnimeStreamTheme(
        accentColor: const Color(0xFF84CC16),
        textMainColor: const Color(0xFFE8F5D0),
        textSubColor: const Color(0xFF9CB56A),
        backgroundColor: const Color(0xFF0D1306),
        backgroundSubColor: const Color(0xFF1A2B0D),
        modalSheetBackgroundColor: const Color(0xFF141F09),
        onAccent: const Color(0xFF0D1306),
      );

  @override
  AnimeStreamTheme get lightVariant => AnimeStreamTheme(
        accentColor: const Color(0xFF65A30D),
        textMainColor: const Color(0xFF1A2B0D),
        textSubColor: const Color(0xFF4A7A1A),
        backgroundColor: const Color(0xFFF7FEE7),
        backgroundSubColor: const Color(0xFFECFCCB),
        modalSheetBackgroundColor: const Color(0xFFF0FDF4),
        onAccent: const Color(0xFFFFFFFF),
      );
}
