import 'package:flutter/material.dart';

class AnimeStreamTheme {
  Color accentColor;
  Color textMainColor;
  Color textSubColor;
  Color backgroundColor;
  Color backgroundSubColor;
  Color modalSheetBackgroundColor;
  Color onAccent;

  AnimeStreamTheme({
    required this.accentColor,
    required this.textMainColor,
    required this.textSubColor,
    required this.backgroundColor,
    required this.backgroundSubColor,
    required this.modalSheetBackgroundColor,
    required this.onAccent,
  });
}
