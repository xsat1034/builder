// ignore_for_file: avoid_print
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  REMOTE CONFIG SERVICE
//  Hanya memindahkan baseUrl ke GitHub.
//  Edit file rompak_config di GitHub → domain berubah tanpa rebuild APK.
//
//  URL: https://raw.githubusercontent.com/databestrickster/Rompakfams/refs/heads/main/rompak_config
// ─────────────────────────────────────────────────────────────────────────────

class AppConfig {
  final String baseUrl;

  const AppConfig({required this.baseUrl});

  factory AppConfig.fallback() => const AppConfig(
    baseUrl: 'http://alwayszillxynyabobo.uss4you.my.id:10002',
  );

  factory AppConfig.fromJson(Map<String, dynamic> j) {
    final s = (j['baseUrl'] as String?)?.trim() ?? '';
    return AppConfig(
      baseUrl: s.isNotEmpty ? s : AppConfig.fallback().baseUrl,
    );
  }

  String toJsonString() => jsonEncode({'baseUrl': baseUrl});
}

class ConfigService {
  ConfigService._();
  static final ConfigService instance = ConfigService._();

  static const String _remoteUrl =
      'https://raw.githubusercontent.com/databestrickster/Rompakfams/refs/heads/main/rompak_config';
  static const String _cacheKey     = 'rompak_config_cache';
  static const String _cacheTimeKey = 'rompak_config_cache_time';
  static const Duration _cacheTtl   = Duration(minutes: 30);

  AppConfig _config = AppConfig.fallback();
  AppConfig get config => _config;

  Future<void> init() async {
    await _loadFromCache();
    _fetchRemote(); // background, tidak di-await
  }

  Future<void> _loadFromCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cached = prefs.getString(_cacheKey);
      if (cached != null && cached.isNotEmpty) {
        final json = jsonDecode(cached) as Map<String, dynamic>;
        _config = AppConfig.fromJson(json);
        print('[ConfigService] loaded from cache: ${_config.baseUrl}');
      }
    } catch (e) {
      print('[ConfigService] cache error: $e');
    }
  }

  Future<void> _fetchRemote() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastFetch = prefs.getInt(_cacheTimeKey) ?? 0;
      final elapsed = DateTime.now().millisecondsSinceEpoch - lastFetch;
      if (elapsed < _cacheTtl.inMilliseconds) {
        print('[ConfigService] cache masih fresh');
        return;
      }

      final resp = await http.get(
        Uri.parse(_remoteUrl),
        headers: {'Cache-Control': 'no-cache'},
      ).timeout(const Duration(seconds: 10));

      if (resp.statusCode == 200 && resp.body.isNotEmpty) {
        final json = jsonDecode(resp.body) as Map<String, dynamic>;
        _config = AppConfig.fromJson(json);
        await prefs.setString(_cacheKey, _config.toJsonString());
        await prefs.setInt(_cacheTimeKey, DateTime.now().millisecondsSinceEpoch);
        print('[ConfigService] remote config loaded: ${_config.baseUrl}');
      }
    } catch (e) {
      print('[ConfigService] fetch error (pakai fallback): $e');
    }
  }
}

// Shortcut global
AppConfig get appCfg => ConfigService.instance.config;
