import 'dart:io';

import 'package:otax/core/app/runtimeDatas.dart';
import 'package:otax/core/data/settings.dart';
import 'package:otax/core/data/types.dart';
import 'package:otax/ui/models/widgets/slider.dart';
import 'package:otax/ui/models/widgets/toggleItem.dart';
import 'package:otax/ui/pages/settingPages/common.dart';
import 'package:otax/ui/pages/settingPages/subtitle.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PlayerSetting extends StatefulWidget {
  final bool fromWatchPage;
  const PlayerSetting({super.key, this.fromWatchPage = false});

  @override
  State<PlayerSetting> createState() => PlayerSettingState();
}

class PlayerSettingState extends State<PlayerSetting> {
  @override
  void initState() {
    if (widget.fromWatchPage) {
      SystemChrome.setPreferredOrientations(
          [DeviceOrientation.portraitUp, DeviceOrientation.landscapeRight, DeviceOrientation.landscapeLeft]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
    super.initState();
    readSettings();
  }

  int? skipDuration;
  int? megaSkipDuration;

  late double skipDurationSliderValue;
  late double megaSkipDurationSliderValue;

  bool loaded = false;

  String? preferredQuality;
  String? preferredSubtitleLanguage;

  late bool enableSuperSpeeds;
  late bool doubleTapToSkip;
  late bool enablePipOnMinimize;
  late bool autoOpEdSkip;

  Future<void> readSettings() async {
    final settings = await Settings().getSettings();
    loaded = true;
    setState(() {
      skipDuration = settings.skipDuration ?? 15;
      megaSkipDuration = settings.megaSkipDuration ?? 85;
      preferredQuality = settings.preferredQuality;
      skipDurationSliderValue = skipDuration!.toDouble();
      megaSkipDurationSliderValue = megaSkipDuration!.toDouble();
      enableSuperSpeeds = settings.enableSuperSpeeds ?? false;
      doubleTapToSkip = settings.doubleTapToSkip ?? true;
      enablePipOnMinimize = settings.enablePipOnMinimize ?? false;
      autoOpEdSkip = settings.autoOpEdSkip ?? false;
      preferredSubtitleLanguage = settings.preferredSubtitleLanguage ?? "English";
    });
  }

  Future<void> writeSettings(SettingsModal settings) async {
    await Settings().writeSettings(settings);
    setState(() {
      readSettings();
    });
  }

  Set selectedQualitySet = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.backgroundColor,
      body: SingleChildScrollView(
        child: Container(
          padding: pagePadding(context, bottom: true),
          child: loaded
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    settingPagesTitleHeader(context, "Player"),
                    Container(
                      // padding: EdgeInsets.only(left: 20, right: 20, top: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          item(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsets.only(bottom: 10),
                                  child: Text(
                                    "Skip duration",
                                    style: textStyle(),
                                  ),
                                ),
                                SliderTheme(
                                  data: SliderThemeData(
                                    thumbColor: appTheme.accentColor,
                                    activeTrackColor: appTheme.accentColor,
                                    inactiveTrackColor: appTheme.textSubColor,
                                    valueIndicatorShape: RoundedSliderValueIndicator(height: 30, width: 35, radius: 5),
                                    valueIndicatorTextStyle: TextStyle(
                                      color: appTheme.backgroundColor,
                                      fontFamily: "NotoSans",
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                    ),
                                    valueIndicatorColor: appTheme.accentColor,
                                    trackHeight: 13,
                                    trackShape: MarginedTrack(),
                                    thumbShape: RoundedRectangularThumbShape(width: 10, radius: 5),
                                    activeTickMarkColor: appTheme.backgroundColor,
                                  ),
                                  child: Slider(
                                    onChanged: (val) {
                                      setState(() {
                                        skipDurationSliderValue = val;
                                      });
                                    },
                                    onChangeEnd: (val) {
                                      writeSettings(SettingsModal(skipDuration: skipDurationSliderValue.toInt()));
                                    },
                                    value: skipDurationSliderValue,
                                    divisions: 9,
                                    label: skipDurationSliderValue.round().toString(),
                                    max: 50,
                                    min: 5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          item(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: Text(
                                    "Mega skip duration",
                                    style: textStyle(),
                                  ),
                                ),
                                SliderTheme(
                                  data: SliderThemeData(
                                    thumbColor: appTheme.accentColor,
                                    activeTrackColor: appTheme.accentColor,
                                    inactiveTrackColor: appTheme.textSubColor,
                                    valueIndicatorShape: RoundedSliderValueIndicator(height: 30, width: 40, radius: 5),
                                    valueIndicatorTextStyle: TextStyle(
                                      color: appTheme.backgroundColor,
                                      fontFamily: "NotoSans",
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                    ),
                                    valueIndicatorColor: appTheme.accentColor,
                                    trackHeight: 13,
                                    thumbShape: RoundedRectangularThumbShape(width: 10, radius: 5),
                                    trackShape: MarginedTrack(),
                                    activeTickMarkColor: appTheme.backgroundColor,
                                  ),
                                  child: Slider(
                                    onChanged: (val) {
                                      setState(() {
                                        megaSkipDurationSliderValue = val;
                                      });
                                    },
                                    onChangeEnd: (val) {
                                      writeSettings(
                                          SettingsModal(megaSkipDuration: megaSkipDurationSliderValue.toInt()));
                                    },
                                    value: megaSkipDurationSliderValue,
                                    divisions: 26,
                                    label: megaSkipDurationSliderValue.round().toString(),
                                    max: 150,
                                    min: 20,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          item(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 20),
                                  child: Text(
                                    "Preferred quality",
                                    style: textStyle(),
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.center,
                                  child: SegmentedButton(
                                    style: SegmentedButton.styleFrom(
                                        backgroundColor: appTheme.backgroundSubColor,
                                        selectedBackgroundColor: appTheme.accentColor,
                                        selectedForegroundColor: appTheme.onAccent,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        side: BorderSide(color: appTheme.textSubColor)),
                                    multiSelectionEnabled: false,
                                    showSelectedIcon: false,
                                    onSelectionChanged: (val) {
                                      setState(() {
                                        preferredQuality = val.first;
                                        writeSettings(SettingsModal(preferredQuality: val.first));
                                      });
                                    },
                                    segments: [
                                      segment("360p"),
                                      segment("480p"),
                                      segment("720p"),
                                      segment("1080p"),
                                    ],
                                    selected: <String>{preferredQuality!},
                                  ),
                                ),
                              ],
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.of(context)
                                  .push(MaterialPageRoute(builder: (context) => SubtitleSettingPage()));
                            },
                            child: item(
                              // padding: EdgeInsets.only(top: 10, bottom: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Subtitle settings",
                                        style: textStyle(),
                                      ),
                                      Text(
                                        "customize the subtitles",
                                        style: textStyle().copyWith(color: appTheme.textSubColor, fontSize: 12),
                                      ),
                                    ],
                                  ),
                                  Icon(Icons.arrow_forward_ios_rounded)
                                ],
                              ),
                            ),
                          ),
                          item(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Subtitle Language", style: textStyle()),
                                SizedBox(height: 4),
                                Text(
                                  "Pilih bahasa subtitle yang diutamakan",
                                  style: textStyle().copyWith(color: appTheme.textSubColor, fontSize: 12),
                                ),
                                SizedBox(height: 12),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    for (final lang in ["Indonesian", "English", "Japanese", "Portuguese", "Spanish", "French", "German", "Arabic"])
                                      GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            preferredSubtitleLanguage = lang;
                                          });
                                          writeSettings(SettingsModal(preferredSubtitleLanguage: lang));
                                        },
                                        child: Container(
                                          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                          decoration: BoxDecoration(
                                            color: preferredSubtitleLanguage == lang
                                                ? appTheme.accentColor
                                                : appTheme.backgroundSubColor,
                                            borderRadius: BorderRadius.circular(20),
                                          ),
                                          child: Text(
                                            lang == "Indonesian" ? "🇮🇩 $lang" : lang,
                                            style: TextStyle(
                                              color: preferredSubtitleLanguage == lang
                                                  ? appTheme.onAccent
                                                  : appTheme.textMainColor,
                                              fontSize: 13,
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "* Subtitle Indonesia mungkin tidak tersedia di semua sumber",
                                  style: textStyle().copyWith(color: appTheme.textSubColor, fontSize: 11),
                                ),
                              ],
                            ),
                          ),
                          ToggleItem(
                              label: "Enable super speeds",
                              value: enableSuperSpeeds,
                              description: "Enable extra player speeds",
                              onTapFunction: () {
                                enableSuperSpeeds = !enableSuperSpeeds;
                                writeSettings(SettingsModal(enableSuperSpeeds: enableSuperSpeeds));
                              }),
                          if (Platform.isAndroid)
                            ToggleItem(
                              onTapFunction: () {
                                doubleTapToSkip = !doubleTapToSkip;
                                writeSettings(SettingsModal(doubleTapToSkip: doubleTapToSkip));
                              },
                              label: "Double tap to seek",
                              description: "Double tap left/right to jump $skipDuration seconds",
                              value: doubleTapToSkip,
                            ),
                          ToggleItem(
                            label: "Auto Picture-in-Picture",
                            description: "Enter PiP automatically when minimized",
                            value: enablePipOnMinimize,
                            onTapFunction: () {
                              enablePipOnMinimize = !enablePipOnMinimize;
                              writeSettings(SettingsModal(enablePipOnMinimize: enablePipOnMinimize));
                            },
                          ),
                          ToggleItem(
                            label: "Auto Op/Ed Skip",
                            description: "Auto skip opening and ending themes",
                            value: autoOpEdSkip,
                            onTapFunction: () {
                              autoOpEdSkip = !autoOpEdSkip;
                              writeSettings(SettingsModal(autoOpEdSkip: autoOpEdSkip));
                            },
                          ),
                        ],
                      ),
                    )
                  ],
                )
              : Container(),
        ),
      ),
    );
  }

  Container item({required Widget child}) {
    return Container(
      padding: EdgeInsets.fromLTRB(20, 15, 20, 15),
      child: child,
    );
  }

  ButtonSegment segment(String label) {
    return ButtonSegment(
      value: label,
      label: Text(
        label,
        style: TextStyle(
          // color: preferredQuality == label ? appTheme.backgroundColor : appTheme.accentColor,
          fontSize: 16,
          fontFamily: "NotoSans",
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  @override
  void dispose() {
    if (widget.fromWatchPage) {
      SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeRight, DeviceOrientation.landscapeLeft]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      SystemChrome.setPreferredOrientations(
          [DeviceOrientation.portraitUp, DeviceOrientation.landscapeRight, DeviceOrientation.landscapeLeft]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
    super.dispose();
  }
}
