import 'package:flutter/material.dart';

void main() => runApp(const TestApp());

class TestApp extends StatelessWidget {
  const TestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text('Flutter APK Test')),
        body: const Center(
          child: Text('APK berhasil dibuat!', style: TextStyle(fontSize: 24)),
        ),
      ),
    );
  }
}
