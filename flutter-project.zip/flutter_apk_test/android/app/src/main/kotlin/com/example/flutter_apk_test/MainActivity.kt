package com.example.flutter_apk_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
